package com.capgemini.parallelProject.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.parallelProject.exception.AccountException;
import com.capgemini.parallelProject.service.AccountService;
import com.capgemini.parallelProject.service.AccountServiceImpl;

public class Customer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = new Scanner(System.in);
		do {
			
			System.out.println("*** welcome to XYZ Bank***");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show Balance");
			System.out.println("6.Print Transactions");
			System.out.println("7.exit");
			
			AccountService service = new AccountServiceImpl();

			int choice = 0;
			boolean choiceFlag = false;
			
			do {
				
				
				System.out.println("Enter input:");
				
				try {
					
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean nameFlag = false;
					boolean numberFlag = false;
					boolean genderFlag=false;
                   // boolean accountFlag=false;
                   
					switch (choice) {
					case 1:
						 String firstName="";
						String middleName="";
						String lastName="";
						do {
						System.out.println("Enter First Name:");
						firstName=scanner.next();
						try {
							service.validateName(firstName);
							nameFlag = true;
						} catch (AccountException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!nameFlag);
						
						do {
						System.out.println("Enter Middle Name:");
						middleName=scanner.next();
						try {
							service.validateName(middleName);
							nameFlag = true;
						} catch (AccountException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!nameFlag);
						
						do {
						System.out.println("Enter Last Name:");
						lastName=scanner.next();
						try {
							service.validateName(lastName);
							nameFlag = true;
						} catch (AccountException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!nameFlag);
						
						String name="";
						
						do {
						name=firstName.concat(middleName.concat(lastName));
						try {
							service.validateName(firstName);
							nameFlag = true;
						} catch (AccountException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!nameFlag);
						
						//System.out.println(name);
						
						String mobileNo="";
						do {
						System.out.println("Enter mobile number:");
						mobileNo=scanner.next();
						try {
							service.validateNumber(mobileNo);
							numberFlag = true;
						} catch (AccountException e) {
							numberFlag = false;
							System.err.println(e.getMessage());
						}
						}while (!numberFlag);
						//System.out.println(name+"  "+mobileNo);
						
						String gender="";
						do {
						System.out.println("Enter Gender:");
						 gender=scanner.next();
						if(gender.equals("male")) {
							gender="Male";
							genderFlag=true;
						}
						else if(gender.equals("female")) {
							gender="Female";
							genderFlag=true;
						}
						else {
							System.out.println("gender should be in characters and it should be either male or female");
							genderFlag=false;
						}
						}while (!genderFlag);
						
					//System.out.println(gender);
						break;
					case 2:
						 boolean accountFlag=false;
						 boolean amountFlag=false;
						String accountNo="";
						double amount=0;
						do {
							
							System.out.println("Enter account number:");
								accountNo=scanner.next();
							
							try {
								service.validateAccountNumber(accountNo);
								accountFlag = true;
							} catch (AccountException e) {
								accountFlag = false;
								System.err.println(e.getMessage());
							}
							
						}while(!accountFlag);
						
						do {
							System.out.println("Enter amount:");
							try {
								amount = scanner.nextDouble();
								service.validateAmount(amount);
								amountFlag = true;
							}/* catch (InputMismatchException e) {
								amountFlag = false;
								System.err.println("Cost should be in digits");
							} */catch (AccountException e) {
								amountFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!amountFlag);

						break;
					
					case 3:
						break;
						
					case 4:
						break;
						
					case 5:
						break;
						
					case 6:
						break;
						
					case 7:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
						
					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;
						
					}
				}catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
				
			}while(!choiceFlag);
			
			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
			
		}while (continueValue);
		scanner.close();
	}

}
