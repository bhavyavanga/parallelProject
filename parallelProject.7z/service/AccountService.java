package com.capgemini.parallelProject.service;

import com.capgemini.parallelProject.exception.AccountException;

public interface AccountService {

	public boolean validateName(String name) throws AccountException;
	public boolean validateNumber(String mobileNo) throws AccountException;
	public boolean validateAccountNumber(String accountNo) throws AccountException;
	public boolean validateAmount(double accountNo) throws AccountException;
	
}
