package com.capgemini.parallelProject.dao;

public class AccountDaoImpl implements AccountDao {

}
