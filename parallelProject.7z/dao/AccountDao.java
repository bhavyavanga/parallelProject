package com.capgemini.parallelProject.dao;

public interface AccountDao {

	
	
	
	
}
