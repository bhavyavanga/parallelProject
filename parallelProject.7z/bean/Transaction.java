package com.capgemini.parallelProject.bean;

import java.util.Date;

public class Transaction {

	int transactionId;
	Date transactionDate;
	int accountNo;
	long balance;
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int transactionId, Date transactionDate, int accountNo, long balance) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.accountNo = accountNo;
		this.balance = balance;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "transactionId=" + transactionId + ", transactionDate=" + transactionDate + ", accountNo="
				+ accountNo + ", balance=" + balance;
	}
	
}
